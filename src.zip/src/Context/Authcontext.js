import React, { createContext, useEffect, useState } from 'react';
import { loginApi } from './index';

import { redirect, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
export const AuthContext = createContext();

const AuthContextProvider = ({ children }) => {
  const [isLogin, setIsLogin] = useState(false);
  const [loggedUser, setLoggedUser] = useState(null);
  const navigate = useNavigate();
  function LoginAPI(email, password) {
    loginApi(email, password)
      .then((response) => {
        const token = response.data.token;
        localStorage.setItem('auth-token', token);
        toast(`${response.data.message} with code ${response.status}`);
        // Check if the token exists in local storage
        const isTokenExists = localStorage.getItem('auth-token');
        // Update the authentication state based on token existence
        setIsLogin(!!isTokenExists);
        navigate('/');
        window.location.reload();
      })
      .catch((error) => {
        toast('login failed, Please try again ');
      });
  }

  return (
    <AuthContext.Provider value={{ isLogin, LoginAPI }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContextProvider;
