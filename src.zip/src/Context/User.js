import axios from './index';

export async function loginApi(email, password) {
  return axios.post('/login', {
    email,
    password,
  });
}

