import Axios from 'axios';

// const url = 'https://ordersystem.onrender.com/auth/'
const url = 'http://localhost:6060/';

Axios.defaults.baseURL = url;
Axios.defaults.headers.common['Content-Type'] = 'application/json';
Axios.interceptors.request.use(
  function (config) {
    const token = localStorage.getItem('auth-token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  function (error) {
    return Promise.reject(error);
  }
);

export async function loginApi(email, password) {
  return Axios.post('auth/login', {
    email,
    password,
  });
}

export async function getLoggedInUser() {
  return Axios.get('auth/getuser');
}
export const addCategory = async (formdata) => {
  Axios.post('categories/add', formdata, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
};
export const getCategory = () => {
  return Axios.get('categories');
};
export const getusers = () => {
  return Axios.get('auth/getuser');
};
export const logout = () => {
  return Axios.get('auth/logout');
};

export const getallcategory = () => {
  return Axios.get('categories');
};
export const GetsingleCategory = (catoId) => {
  return Axios.get(`categories/${catoId}`);
};

export const addproduct = (formdata) => {
  Axios.post('/product/add', formdata, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  })
    .then((res) => window.alert(' Product added  successful'))
    .catch((error) => console.log(error));
};
export const getproduct = (catoId) => {
  return Axios.get('product');
};

// export default axios;
