import React, { useContext, useState } from 'react';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import style from '../../Modulecss/Auth.module.css';
import { toast } from 'react-toastify';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import AuthContext from '../../Context/context';
import { addCategory } from '../../Context';
function Addcategory() {
  const [image, setimage] = useState(null);
  const [inputval, setinupt] = useState();
  const user = useContext(AuthContext);
  console.log(user);
  const loggedUser = {};
  const handleinput = (event) => {
    const { name, value } = event.target;
    setinupt({ ...inputval, [name]: value });
  };

  const handlesubmit = (event) => {
    event.preventDefault();
    const { name, slug } = inputval;
    console.log(image);
    if (name || slug || image || loggedUser) {
      const formdata = new FormData();
      formdata.append('name', name);
      formdata.append('slug', slug);
      formdata.append('image', image);
      formdata.append('owner', loggedUser._id);
      addCategory(formdata)
        .then((res) => toast.success('Category added '))
        .catch((error) => toast.error('someting bad happen ! '));
    } else {
      window.alert('invalid input! ');
    }
  };
  return (
    <div className='container'>
      <div className=' w-1/2 m-auto absolute top-10 left-0 right-0 '>
        <div className='card w-1/2 m-auto p-4'>
          <form action='' onSubmit={handlesubmit}>
            <FloatingLabel
              controlId='floatingInput'
              label='Name'
              className='mb-3'
            >
              <Form.Control
                type='text'
                name='name'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>
            <FloatingLabel
              controlId='floatingInput'
              label='Slug'
              className='mb-3'
            >
              <Form.Control
                type='text'
                name='slug'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>

            <FloatingLabel
              controlId='floatingInput'
              label='Image'
              className='mb-3'
            >
              <Form.Control
                type='file'
                onChange={(ev) => setimage(ev.target.files[0])}
              />
            </FloatingLabel>

            <Form.Control type='submit' value='Submit' className={style.btn} />
          </form>
        </div>
      </div>
    </div>
  );
}

export default Addcategory;
