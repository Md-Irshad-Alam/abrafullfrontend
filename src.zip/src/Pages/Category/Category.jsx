import React, { useContext } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Stack from 'react-bootstrap/Stack';
import AuthContext from '../../Context/context';
import Table from 'react-bootstrap/Table';
function Category() {
  return (
    <Stack
      direction='horizontal'
      gap={3}
      className='w-80 absolute top-36 left-0 right-0 m-auto flex justify-between'
    >
      <div className='flex justify-between w-full'>
        <Table responsive>
          <thead>
            <tr>
              <td>Category</td>
            </tr>
            <tr>
              <td>Slug</td>
            </tr>
            <tr>
              <td>Image</td>
            </tr>
          </thead>
          {/* {categories.map((ele, id) => {
            return (
              <tbody>
                <tr>
                  <td>Category</td>
                </tr>
                <tr>
                  <td>Slug</td>
                </tr>
                <tr>
                  <td>Image</td>
                </tr>
              </tbody>
            );
          })} */}
        </Table>
      </div>
    </Stack>
  );
}

export default Category;
