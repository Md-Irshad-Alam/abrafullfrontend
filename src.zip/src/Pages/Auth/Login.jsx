import React, { useContext, useState } from 'react';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import style from '../../Modulecss/Auth.module.css';
import LeftBackround from './LeftBackround';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import AuthContextProvider from '../../Context/Authcontext';
function Login() {
  const [inputval, setinput] = useState({});

  const handleinput = (evnet) => {
    const { name, value } = evnet.target;
    setinput({ ...inputval, [name]: value });
  };
  const { login } = useContext();
  console.log(login);
  const history = useNavigate();
  const handlesubmit = (event) => {
    event.preventDefault();
    const { email, password } = inputval;
    if (email || password) {
      login(email, password);
    }
  };

  return (
    <div className='container'>
      <div className=' w-1/2 m-auto absolute top-10 left-0 right-0 '>
        {/* <LeftBackround /> */}

        <div className='card w-1/2 m-auto p-4'>
          <form action='' onSubmit={handlesubmit}>
            <FloatingLabel
              controlId='floatingInput'
              label='Email'
              className='mb-3'
            >
              <Form.Control
                type='email'
                name='email'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>
            <FloatingLabel
              controlId='floatingInput'
              label='Password'
              className='mb-3'
            >
              <Form.Control
                type='password'
                name='password'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>

            <Form.Control type='submit' value='Signup' className={style.btn} />
          </form>
          <p className='mt-4'>
            Want to register{' '}
            <span
              className='color text-green-400'
              onClick={() => history('/register')}
            >
              Go to register
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;
