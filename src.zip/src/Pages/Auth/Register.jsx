import React, { useState } from 'react';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import style from '../../Modulecss/Auth.module.css';
import LeftBackround from './LeftBackround';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
function Register() {
  const [inputval, setinput] = useState({});
  const [image, setimage] = useState(null);
  const handleinput = (evnet) => {
    const { name, value } = evnet.target;
    setinput({ ...inputval, [name]: value });
  };
  const history = useNavigate();
  const handlesubmit = (event) => {
    event.preventDefault();
    const { name, username, email, password } = inputval;
    if (name || username || email || password || image) {
      const formdata = new FormData();
      formdata.append('name', name);
      formdata.append('username', username);
      formdata.append('email', email);
      formdata.append('password', password);
      formdata.append('avatar', image);
      axios
        .post('http://localhost:6060/auth/register', formdata, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        })
        .then((res) => history('/login'))
        .catch((error) => window.alert('something went wrong!'));
    }
  };

  return (
    <div className='container'>
      <div className=' m-auto  absolute top-10 left-0 right-0 flex justify-center'>
        {/* <LeftBackround /> */}
        <div className=''>
          <form action='' onSubmit={handlesubmit}>
            <FloatingLabel
              controlId='floatingInput'
              label='Full Name'
              className='mb-3'
            >
              <Form.Control
                type='text'
                name='name'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>
            <FloatingLabel
              controlId='floatingInput'
              label='Username'
              className='mb-3'
            >
              <Form.Control
                type='text'
                name='username'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>
            <FloatingLabel
              controlId='floatingInput'
              label='Email'
              className='mb-3'
            >
              <Form.Control
                type='email'
                name='email'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>
            <FloatingLabel
              controlId='floatingInput'
              label='Password'
              className='mb-3'
            >
              <Form.Control
                type='password'
                name='password'
                onChange={(ev) => handleinput(ev)}
              />
            </FloatingLabel>

            <FloatingLabel
              controlId='floatingPassword'
              className='mb-3'
              label='Avatar'
            >
              <Form.Control
                type='file'
                onChange={(ev) => setimage(ev.target.files[0])}
              />
            </FloatingLabel>
            <Form.Control type='submit' value='Signup' className={style.btn} />
          </form>
          <p className='mt-4'>
            Already register{' '}
            <span
              className='color text-green-400'
              onClick={() => history('/login')}
            >
              Go to login
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Register;
