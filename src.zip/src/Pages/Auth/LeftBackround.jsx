import React from 'react';
import style from '../../Modulecss/Auth.module.css';
function LeftBackround() {
  return (
    <div className={style.mainpart}>
      <div className={style.innerpart}>
        <div className={style.topleft}></div>
        <div className={style.bottomright}></div>
      </div>
    </div>
  );
}

export default LeftBackround;
