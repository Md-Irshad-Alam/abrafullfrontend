import React, { useContext, useState } from 'react';
import style from '../Modulecss/navbar.module.css';
import { FaUserTie } from 'react-icons/fa';
import { MdLocalGroceryStore } from 'react-icons/md';
import AuthContext from '../Context/context';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
function Navbar() {
  const [show, setshow] = useState(false);
  const handlshow = () => {
    setshow(!show);
  };
  const history = useNavigate();
  const handlelogout = () => {
    window.alert('user logout');
    setshow(true);
  };
  return (
    <div className='container absolute top-4 left-0 right-0'>
      <div className='flex justify-between p-4'>
        <div className=''>
          <h4 className='tex text-2xl font-bold'>Logo</h4>
        </div>
        <div className='flex items-center gap-x-6 text-2xl'>
          <MdLocalGroceryStore />
          <FaUserTie onClick={() => handlshow()} />
        </div>
      </div>
      <div className={show ? style.show : style.hide}>
        <Link to='/card'>Cart</Link>
        <Link to='/profile'>profile</Link>
        <p>
          {show ? (
            <p onClick={() => history('/login')}>Login</p>
          ) : (
            <p onClick={() => handlelogout()}>Logout</p>
          )}
        </p>
      </div>
    </div>
  );
}

export default Navbar;
