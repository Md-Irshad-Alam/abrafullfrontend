import React from 'react';

import { ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import { Routes, Route } from 'react-router-dom';
import Register from './Pages/Auth/Register';
import Login from './Pages/Auth/Login';
import ViewProfile from './Pages/ViewProfile';
import Addcategory from './Pages/Category/Addcategory';
import Category from './Pages/Category/Category';
import Navbar from './Pages/Navbar';
import AuthContextProvider from './Context/Authcontext';

function App() {
  return (
    <AuthContextProvider>
      <ToastContainer />
      <Navbar />
      <Routes>
        {/* {islogin === false ? (
          <Route path='/login' element={<Login />} />
        ) : (
          <>
            <Route path='/product' element={<Product />} />
            <Route path='/product/:productId' element={<PlaceOrder />} />
            <Route path='/order' element={<GetOrder />} />
            {loggedUser.isAdmin === true ? (
              <>
                <Route path='/approve' element={<ApprovedOrder />} />
                <Route path='/add' element={<AddProdcuts />} />
              </>
            ) : (
              <Route path='*' element={'Unathorized person '} />
            )}
          </>
        )} */}

        <Route path='/register' element={<Register />} />
        <Route path='/login' element={<Login />} />
        <Route path='/profile' element={<ViewProfile />} />
        <Route path='/category' element={<Addcategory />} />

        <Route path='/viewcategory' element={<Category />} />
      </Routes>
    </AuthContextProvider>
  );
}

export default App;
